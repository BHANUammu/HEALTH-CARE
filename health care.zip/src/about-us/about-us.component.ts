import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'abt-root',
  templateUrl: './about-us.component.html'
  
})

export class AboutComponent {
   constructor(private route: ActivatedRoute, private router: Router) { };

  title = 'about-us';
  imgWidth=700;
  imgHeight=400;


 onBack(): void {

        this.router.navigate(['/home']);
    }


}
