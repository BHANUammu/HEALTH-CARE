import { Component } from '@angular/core';

@Component({
  selector: 'error-root',
  templateUrl: './error.component.html',
  //styleUrls: ['./error.component.css']
})
export class ErrorComponent {
  title = 'title';
}
