export interface IDoctor{

    dID:number;
    doctorName:string;
    hospital:string;
    Specialization:string;
    mobileno:number;
 exp:string;
 image:string;
 
}