import {Component, OnInit, OnChanges, OnDestroy} from '@angular/core';
import { IDoctor } from './doctor';
import { ActivatedRoute, Router } from "@angular/router";

@Component({

  selector:'doc-app', 
  templateUrl:'./doctor.component.html',
  
})

export class DoctorComponent implements  OnInit,OnChanges,OnDestroy{
 constructor(private route: ActivatedRoute, private router: Router) { };

  ngOnInit(): void {
   
  }

  ngOnChanges(): void {

  console.log("At the Change detection phase!");  
  }
  ngOnDestroy(): void {
    console.log("Destroying the component");
  }

  imgWidth:number=400;
  imgHeight:number=500;
  


  docTitle="Top doctors";

  doctors:IDoctor[] = [
    {
      dID:1,
      doctorName:"sunitha",
      hospital:"appolo",
      Specialization:"cardiologist",
      mobileno:9857432543,
      exp:"10 years",
      image:"./assets/image/heart.jpg"
  },
  {
      dID:2,
      doctorName:"prabhakar",
      hospital:"rainbow",
      Specialization:"Family Physicians",
      mobileno:9524432543,
       exp:"10 years",
       image:"./assets/image/family.jpg"
  },
  {
      dID:3,
      doctorName:"kavitha",
      hospital:"kims ",
      Specialization:"neurologist",
      mobileno:7981667013,
       exp:"10 years",
        image:"./assets/image/neu.jpg"
  },
  {
      dID:4,
      doctorName:"badrinath",
      hospital:"manipall",
      Specialization:"orthopaedic",
      mobileno:8886551128,
       exp:"10 years",
        image:"./assets/image/orth.jpg"
  }
  
  


  ];
  
 onBack(): void {

        this.router.navigate(['/home']);
    }
   

  
}