import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//import {HealthComponent } from 'src/health/health.component';
import {HomeComponent } from 'src/home/home.component';
import {DoctorDetailsComponent } from 'src/doctor-details/doctor-details.component';
import {UserComponent} from 'src/user/user.component';
import {DoctorComponent} from 'src/doctor/doctor.component';
import {AboutComponent} from 'src/about-us/about-us.component';
const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'doctor-details/:id',component:DoctorDetailsComponent},
  {path:'about-us',component:AboutComponent},
  {path:'user',component:UserComponent},
    {path:'doctor',component:DoctorComponent},
  {path:'',component:HomeComponent,pathMatch:'full'},
  {path:'**',component:HomeComponent,pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
