import { IDoctor } from '../doctor/doctor';
import { ActivatedRoute, Router } from '@angular/router';
import { OnInit, Component } from '@angular/core';

@Component({
    templateUrl: './../doctor-details/doctor-details.component.html',
 //template:`<h1>Details</h1>`
})
export class DoctorDetailsComponent implements OnInit {

    title: string = "Doctor Details";
    doctor: IDoctor;
   
    constructor(private route: ActivatedRoute, private router: Router) { };

    ngOnInit() {

        let id = +this.route.snapshot.paramMap.get('dID');
        this.title +=  '';
        this.doctor = {
            dID:id,
            doctorName:"Dr.SUNITHA",
            hospital:"appolo",
            Specialization:"heart surgen",
             mobileno:9857432543,
             exp:"10 years",
             image:""
        }

    }

    onBack(): void {

        this.router.navigate(['/doctor']);
    }

}

